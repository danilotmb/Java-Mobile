package it.corso.model;

import android.text.Editable;

import java.util.ArrayList;
import java.util.List;

public class Contact
{
    private String name;
    private String lastName;
    private String mail;
    private String contactPhone;
    private String contactAddress;
    private String contactAddressDetail;
    private String caap;
    private String city;
    private String province;

    private static List<Contact> contacts = new ArrayList<>();

    public Contact(String name, String lastName, String mail, String contactPhone, String contactAddress,
                   String contactAddressDetail, String caap, String city,
                   Editable text, String province)
    {
        this.name = name;
        this.lastName = lastName;
        this.mail = mail;
        this.contactPhone = contactPhone;
        this.contactAddress = contactAddress;
        this.contactAddressDetail = contactAddressDetail;
        this.caap = caap;
        this.city = city;
        this.province = province;
    }

    public static List<Contact> getContacts() {
        return contacts;
    }

    public static void setContacts(List<Contact> contacts) {
        Contact.contacts = contacts;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getContactAddress() {
        return contactAddress;
    }

    public void setContactAddress(String contactAddress) {
        this.contactAddress = contactAddress;
    }

    public String getContactAddressDetail() {
        return contactAddressDetail;
    }

    public void setContactAddressDetail(String contactAddressDetail) {
        this.contactAddressDetail = contactAddressDetail;
    }

    public String getCaap() {
        return caap;
    }

    public void setCaap(String caap) {
        this.caap = caap;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        province = province;
    }

    }

