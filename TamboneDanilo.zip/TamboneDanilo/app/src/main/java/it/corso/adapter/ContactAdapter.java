package it.corso.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import it.corso.R;
import it.corso.model.Contact;

public class ContactAdapter extends BaseAdapter
{

    private final LayoutInflater INFLATER;

    public ContactAdapter(Context context)
    {
        INFLATER = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return Contact.getContacts().size();
    }


    @Override
    public Contact getItem(int i) {
        return Contact.getContacts().get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view= INFLATER.inflate(R.layout.contact_item, null);
        TextView nameLastname = view.findViewById(R.id.contact_item_name_lastname);
        TextView mail = view.findViewById(R.id.contact_item_mail);
        Contact contact = getItem(i);
        nameLastname.setText(contact.getName() + "" + contact.getLastName());
        mail.setText(contact.getMail());
        return view;
    }
}
