package it.corso.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import it.corso.R;
import it.corso.adapter.ContactAdapter;
import it.corso.model.Contact;

public class MainActivity extends AppCompatActivity {

    Integer itemPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton addButton = findViewById(R.id.add_btn);

        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,
                    RegistrationActivity.class);
            startActivity(intent);
            finish();

        });

        Log.i("contacts", Contact.getContacts().toString());
        ListView contactList = findViewById(R.id.contact_list);
        ContactAdapter adapter = new ContactAdapter(this);
        contactList.setAdapter(adapter);

        contactList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                LinearLayout actionLayout = view.findViewById(R.id.contact_action_layout);
                ImageView deleteButton = view.findViewById(R.id.delete_btn);



                actionLayout.setVisibility(View.VISIBLE);

                if(itemPosition == null)
                    itemPosition = i;
                if(itemPosition != null && itemPosition != i)
                {
                    contactList
                            .getChildAt(itemPosition)
                            .findViewById(R.id.contact_action_layout)
                            .setVisibility(View.GONE);
                    itemPosition = i;
                }

                deleteButton.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        Contact.getContacts().remove(i);
                        adapter.notifyDataSetChanged();
                    }
                });
            }



        });


    }
}