package it.corso.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import it.corso.R;
import it.corso.model.Contact;

public class RegistrationActivity extends AppCompatActivity {

    private EditText contactName, contactLastName, contactMail, contactPhone,contactAddress, contactAddressDetail, caap, city, province;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        contactName = findViewById(R.id.contact_name);
        contactLastName = findViewById(R.id.contact_lastname);
        contactMail = findViewById(R.id.contact_mail);
        contactPhone = findViewById(R.id.contactPhone);
        contactAddress = findViewById(R.id.contactAddress);
        contactAddressDetail = findViewById(R.id.contactAddressDetail);
        caap = findViewById(R.id.caap);
        city = findViewById(R.id.city);
        province = findViewById(R.id.province);

        Button addButton = findViewById(R.id.contact_add_btn);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                formManager();
            }
        });
    }

    private void formManager()
    {
        Contact contact = new Contact(
                contactName.getText().toString(),
                contactLastName.getText().toString(),
                contactMail.getText().toString(),
                contactPhone.getText().toString(),
                contactAddress.getText().toString(),
                contactAddressDetail.getText().toString(),
                caap.getText().toString(),
                city.getText().toString(),
                province.getText(),toString()

        );

        Contact.getContacts().add(contact);

        Intent intent = new Intent(
                RegistrationActivity.this,
                MainActivity.class
        );
        startActivity(intent);
        finish();
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(RegistrationActivity.this,
                    MainActivity.class);

            startActivity(intent);
            finish();
        }
        return true;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(RegistrationActivity.this,
                MainActivity.class);

        startActivity(intent);
        finish();
    }
}